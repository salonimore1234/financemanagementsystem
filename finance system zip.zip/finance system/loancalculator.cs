﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login
{
    public partial class loancalculator : Form
    {
        public loancalculator()
        {
            InitializeComponent();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void loancalculator_Load(object sender, EventArgs e)
        {
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Confirm if you want to Exit", " Loan system", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtamountofloan.Clear();
            txtinterestrate.Clear();
            txtnumberofyear.Clear();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            
        }

        private void loanAmount_Click(object sender, EventArgs e)
        {

        }

        private void btngenerate_Click(object sender, EventArgs e)
        {
            txtresult.Clear();
            txtresult.Text += "*************************************************************\n";
            txtresult.Text += "**        LOAN MANAGEMENT RECEIPT               **\n";
            txtresult.Text += "Date :"+ DateTime.Now+"\n\n";

            txtresult.Text += "Enter Amount of Loan : " + txtamountofloan.Text + "\n\n";
            txtresult.Text += "Enter Number of Year : " + txtnumberofyear.Text + "\n\n";
            txtresult.Text += "Enter Interest Rate : " + txtinterestrate.Text + "\n\n";
            txtresult.Text += "Enter Total Amount:" + txtmonthlypayment.Text + "n\n";
        }

        private void btnprint_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(txtresult.Text, new Font("Microsoft Sans Serif", 18, FontStyle.Bold), Brushes.Black, new Point(10, 10));
        }

        private void lbltotalpayment_Click(object sender, EventArgs e)
        {

        }

        private void txtresult_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
             
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            
            
        }
    }
}
