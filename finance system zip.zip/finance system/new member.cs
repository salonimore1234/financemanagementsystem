﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace login
{
    public partial class new_member : Form
    {
        public new_member()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void nmBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.nmBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.nmDataSet);
            MessageBox.Show(" Save Successfully!!");

        }

        private void new_member_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'nmDataSet.nm' table. You can move, or remove it, as needed.
            this.nmTableAdapter.Fill(this.nmDataSet.nm);

        }

        private void mobile_No_TextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void amount_Label_Click(object sender, EventArgs e)
        {

        }

        private void email_TextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtsave_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void mobile_No_TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != 8)
            {
                MessageBox.Show("Enter Numbers Only");
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void amount_TextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void amount_TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != 8)
            {
                MessageBox.Show("Enter Numbers Only");
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void name_TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) == false && Convert.ToInt32(e.KeyChar) != 8)
                if (e.KeyChar != ' ')
                {
                    MessageBox.Show("Enter Characters Only");
                    e.Handled = true;
                }
        }

        private void email_TextBox_Leave(object sender, EventArgs e)
        {
            string pattern = " ^([0-9a-zA-Z] ([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
            if (Regex.IsMatch(email_TextBox.Text, pattern))
            {
                errorProvider1.Clear();
            }
            else
            {
                errorProvider1.SetError(this.email_TextBox, "Please Enter Valid Email Address");
            }
        }
    }
}
