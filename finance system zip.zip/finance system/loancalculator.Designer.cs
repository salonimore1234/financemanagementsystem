﻿
namespace login
{
    partial class loancalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(loancalculator));
            this.btngenerate = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.loanAmount = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtamountofloan = new System.Windows.Forms.TextBox();
            this.txtnumberofyear = new System.Windows.Forms.TextBox();
            this.txtinterestrate = new System.Windows.Forms.TextBox();
            this.txtresult = new System.Windows.Forms.RichTextBox();
            this.Paymentperiods = new System.Windows.Forms.Label();
            this.Payment = new System.Windows.Forms.Label();
            this.InterestRate = new System.Windows.Forms.Label();
            this.btnprint = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.txtmonthlypayment = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btngenerate
            // 
            this.btngenerate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btngenerate.Location = new System.Drawing.Point(377, 631);
            this.btngenerate.Name = "btngenerate";
            this.btngenerate.Size = new System.Drawing.Size(203, 61);
            this.btngenerate.TabIndex = 1;
            this.btngenerate.Text = "Generate Receipt";
            this.btngenerate.UseVisualStyleBackColor = true;
            this.btngenerate.Click += new System.EventHandler(this.btngenerate_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(61, 631);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(203, 61);
            this.button3.TabIndex = 2;
            this.button3.Text = "Reset ";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(918, 631);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(203, 61);
            this.button4.TabIndex = 3;
            this.button4.Text = "Exit ";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // loanAmount
            // 
            this.loanAmount.AutoSize = true;
            this.loanAmount.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loanAmount.Location = new System.Drawing.Point(23, 161);
            this.loanAmount.Name = "loanAmount";
            this.loanAmount.Size = new System.Drawing.Size(280, 32);
            this.loanAmount.TabIndex = 4;
            this.loanAmount.Text = "Enter amount of Loan";
            this.loanAmount.Click += new System.EventHandler(this.loanAmount_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(269, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(600, 43);
            this.label6.TabIndex = 10;
            this.label6.Text = "LOAN MANAGEMENT RECEIPT";
            // 
            // txtamountofloan
            // 
            this.txtamountofloan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtamountofloan.Location = new System.Drawing.Point(367, 144);
            this.txtamountofloan.Multiline = true;
            this.txtamountofloan.Name = "txtamountofloan";
            this.txtamountofloan.Size = new System.Drawing.Size(226, 49);
            this.txtamountofloan.TabIndex = 10;
            // 
            // txtnumberofyear
            // 
            this.txtnumberofyear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnumberofyear.Location = new System.Drawing.Point(367, 233);
            this.txtnumberofyear.Multiline = true;
            this.txtnumberofyear.Name = "txtnumberofyear";
            this.txtnumberofyear.Size = new System.Drawing.Size(226, 49);
            this.txtnumberofyear.TabIndex = 11;
            // 
            // txtinterestrate
            // 
            this.txtinterestrate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinterestrate.Location = new System.Drawing.Point(367, 327);
            this.txtinterestrate.Multiline = true;
            this.txtinterestrate.Name = "txtinterestrate";
            this.txtinterestrate.Size = new System.Drawing.Size(226, 49);
            this.txtinterestrate.TabIndex = 12;
            // 
            // txtresult
            // 
            this.txtresult.Location = new System.Drawing.Point(771, 111);
            this.txtresult.Name = "txtresult";
            this.txtresult.Size = new System.Drawing.Size(474, 460);
            this.txtresult.TabIndex = 15;
            this.txtresult.Text = "";
            this.txtresult.TextChanged += new System.EventHandler(this.txtresult_TextChanged);
            // 
            // Paymentperiods
            // 
            this.Paymentperiods.AutoSize = true;
            this.Paymentperiods.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Paymentperiods.Location = new System.Drawing.Point(23, 250);
            this.Paymentperiods.Name = "Paymentperiods";
            this.Paymentperiods.Size = new System.Drawing.Size(278, 32);
            this.Paymentperiods.TabIndex = 16;
            this.Paymentperiods.Text = "Enter Number of Year";
            // 
            // Payment
            // 
            this.Payment.AutoSize = true;
            this.Payment.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Payment.Location = new System.Drawing.Point(23, 468);
            this.Payment.Name = "Payment";
            this.Payment.Size = new System.Drawing.Size(230, 32);
            this.Payment.TabIndex = 17;
            this.Payment.Text = "Monthly Payment";
            // 
            // InterestRate
            // 
            this.InterestRate.AutoSize = true;
            this.InterestRate.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InterestRate.Location = new System.Drawing.Point(23, 344);
            this.InterestRate.Name = "InterestRate";
            this.InterestRate.Size = new System.Drawing.Size(241, 32);
            this.InterestRate.TabIndex = 19;
            this.InterestRate.Text = "Enter Interest Rate";
            // 
            // btnprint
            // 
            this.btnprint.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnprint.Location = new System.Drawing.Point(656, 631);
            this.btnprint.Name = "btnprint";
            this.btnprint.Size = new System.Drawing.Size(203, 61);
            this.btnprint.TabIndex = 22;
            this.btnprint.Text = "Print";
            this.btnprint.UseVisualStyleBackColor = true;
            this.btnprint.Click += new System.EventHandler(this.btnprint_Click);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // txtmonthlypayment
            // 
            this.txtmonthlypayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmonthlypayment.Location = new System.Drawing.Point(367, 451);
            this.txtmonthlypayment.Multiline = true;
            this.txtmonthlypayment.Name = "txtmonthlypayment";
            this.txtmonthlypayment.Size = new System.Drawing.Size(226, 49);
            this.txtmonthlypayment.TabIndex = 23;
            // 
            // loancalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1350, 730);
            this.Controls.Add(this.txtmonthlypayment);
            this.Controls.Add(this.btnprint);
            this.Controls.Add(this.InterestRate);
            this.Controls.Add(this.Payment);
            this.Controls.Add(this.Paymentperiods);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtresult);
            this.Controls.Add(this.txtinterestrate);
            this.Controls.Add(this.txtnumberofyear);
            this.Controls.Add(this.txtamountofloan);
            this.Controls.Add(this.loanAmount);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btngenerate);
            this.Name = "loancalculator";
            this.Text = "loancalculator";
            this.Load += new System.EventHandler(this.loancalculator_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btngenerate;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label loanAmount;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtamountofloan;
        private System.Windows.Forms.TextBox txtnumberofyear;
        private System.Windows.Forms.TextBox txtinterestrate;
        private System.Windows.Forms.RichTextBox txtresult;
        private System.Windows.Forms.Label Paymentperiods;
        private System.Windows.Forms.Label Payment;
        private System.Windows.Forms.Label InterestRate;
        private System.Windows.Forms.Button btnprint;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.TextBox txtmonthlypayment;
    }
}