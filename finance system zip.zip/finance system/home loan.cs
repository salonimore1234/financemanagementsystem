﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login
{
    public partial class home_loan : Form
    {
        public home_loan()
        {
            InitializeComponent();
        }

        private void tableBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tableBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.homeloanDataSet);
            MessageBox.Show(" Home Loan Save Successfully!!");

        }

        private void home_loan_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'homeloanDataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter.Fill(this.homeloanDataSet.Table);

        }

        private void durationTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
