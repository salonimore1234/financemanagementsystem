﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace login
{
    public class All_Customers
    {
        public string Name { get; set; }
        public string MobileNumber { get; set; }
        public string LoanAmount { get; set; }
        public string Duration { get; set; }
        public string LoanType { get; set; }
    }
}
