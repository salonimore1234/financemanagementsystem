﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login
{
    public partial class vehicle_loan : Form
    {
        public vehicle_loan()
        {
            InitializeComponent();
        }

        private void tableBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tableBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.vehicleloanDataSet);
            MessageBox.Show(" Home Loan Save Successfully!!");


        }

        private void vehicle_loan_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'vehicleloanDataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter.Fill(this.vehicleloanDataSet.Table);

        }

        private void amountTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void amountTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != 8)
            {
                MessageBox.Show("Enter Numbers Only");
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void balanceTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != 8)
            {
                MessageBox.Show("Enter Numbers Only");
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void nameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void nameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
          if (char.IsLetter(e.KeyChar) == false && Convert.ToInt32(e.KeyChar) != 8)
                if (e.KeyChar != ' ')
                {
                    MessageBox.Show("Enter Characters Only");
                    e.Handled = true;
                }
        }
    }
}
