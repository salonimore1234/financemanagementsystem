﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login
{
    public partial class LOANS : Form
    {
        public LOANS()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void homeLoanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new home_loan().Show();
        }

        private void vehicleLoanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new vehicle_loan().Show();

        }
    }
}
