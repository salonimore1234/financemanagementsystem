﻿
namespace login
{
    partial class new_member
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label name_Label;
            System.Windows.Forms.Label email_Label;
            System.Windows.Forms.Label mobile_No_Label;
            System.Windows.Forms.Label loan_Type_Label;
            System.Windows.Forms.Label amount_Label;
            System.Windows.Forms.Label duration_Label;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(new_member));
            this.panel1 = new System.Windows.Forms.Panel();
            this.name_TextBox = new System.Windows.Forms.TextBox();
            this.nmBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nmDataSet = new login.nmDataSet();
            this.email_TextBox = new System.Windows.Forms.TextBox();
            this.mobile_No_TextBox = new System.Windows.Forms.TextBox();
            this.loan_Type_TextBox = new System.Windows.Forms.TextBox();
            this.amount_TextBox = new System.Windows.Forms.TextBox();
            this.duration_TextBox = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.nmDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nmBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.nmBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.nmTableAdapter = new login.nmDataSetTableAdapters.nmTableAdapter();
            this.tableAdapterManager = new login.nmDataSetTableAdapters.TableAdapterManager();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            name_Label = new System.Windows.Forms.Label();
            email_Label = new System.Windows.Forms.Label();
            mobile_No_Label = new System.Windows.Forms.Label();
            loan_Type_Label = new System.Windows.Forms.Label();
            amount_Label = new System.Windows.Forms.Label();
            duration_Label = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmDataSet)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmBindingNavigator)).BeginInit();
            this.nmBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // name_Label
            // 
            name_Label.AutoSize = true;
            name_Label.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            name_Label.ForeColor = System.Drawing.Color.White;
            name_Label.Location = new System.Drawing.Point(43, 165);
            name_Label.Name = "name_Label";
            name_Label.Size = new System.Drawing.Size(92, 32);
            name_Label.TabIndex = 1;
            name_Label.Text = "Name:";
            // 
            // email_Label
            // 
            email_Label.AutoSize = true;
            email_Label.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            email_Label.ForeColor = System.Drawing.Color.White;
            email_Label.Location = new System.Drawing.Point(43, 249);
            email_Label.Name = "email_Label";
            email_Label.Size = new System.Drawing.Size(95, 32);
            email_Label.TabIndex = 3;
            email_Label.Text = "Email:";
            // 
            // mobile_No_Label
            // 
            mobile_No_Label.AutoSize = true;
            mobile_No_Label.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            mobile_No_Label.ForeColor = System.Drawing.Color.White;
            mobile_No_Label.Location = new System.Drawing.Point(43, 337);
            mobile_No_Label.Name = "mobile_No_Label";
            mobile_No_Label.Size = new System.Drawing.Size(149, 32);
            mobile_No_Label.TabIndex = 5;
            mobile_No_Label.Text = "Mobile No:";
            // 
            // loan_Type_Label
            // 
            loan_Type_Label.AutoSize = true;
            loan_Type_Label.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            loan_Type_Label.ForeColor = System.Drawing.Color.White;
            loan_Type_Label.Location = new System.Drawing.Point(43, 424);
            loan_Type_Label.Name = "loan_Type_Label";
            loan_Type_Label.Size = new System.Drawing.Size(151, 32);
            loan_Type_Label.TabIndex = 7;
            loan_Type_Label.Text = "Loan Type:";
            // 
            // amount_Label
            // 
            amount_Label.AutoSize = true;
            amount_Label.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            amount_Label.ForeColor = System.Drawing.Color.White;
            amount_Label.Location = new System.Drawing.Point(43, 515);
            amount_Label.Name = "amount_Label";
            amount_Label.Size = new System.Drawing.Size(121, 32);
            amount_Label.TabIndex = 9;
            amount_Label.Text = "Amount:";
            amount_Label.Click += new System.EventHandler(this.amount_Label_Click);
            // 
            // duration_Label
            // 
            duration_Label.AutoSize = true;
            duration_Label.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            duration_Label.ForeColor = System.Drawing.Color.White;
            duration_Label.Location = new System.Drawing.Point(43, 610);
            duration_Label.Name = "duration_Label";
            duration_Label.Size = new System.Drawing.Size(133, 32);
            duration_Label.TabIndex = 11;
            duration_Label.Text = "Duration:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(name_Label);
            this.panel1.Controls.Add(this.name_TextBox);
            this.panel1.Controls.Add(email_Label);
            this.panel1.Controls.Add(this.email_TextBox);
            this.panel1.Controls.Add(mobile_No_Label);
            this.panel1.Controls.Add(this.mobile_No_TextBox);
            this.panel1.Controls.Add(loan_Type_Label);
            this.panel1.Controls.Add(this.loan_Type_TextBox);
            this.panel1.Controls.Add(amount_Label);
            this.panel1.Controls.Add(this.amount_TextBox);
            this.panel1.Controls.Add(duration_Label);
            this.panel1.Controls.Add(this.duration_TextBox);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Location = new System.Drawing.Point(103, 57);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(607, 769);
            this.panel1.TabIndex = 0;
            // 
            // name_TextBox
            // 
            this.name_TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nmBindingSource, "Name:", true));
            this.name_TextBox.Location = new System.Drawing.Point(282, 154);
            this.name_TextBox.Multiline = true;
            this.name_TextBox.Name = "name_TextBox";
            this.name_TextBox.Size = new System.Drawing.Size(260, 43);
            this.name_TextBox.TabIndex = 2;
            this.name_TextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.name_TextBox_KeyPress);
            // 
            // nmBindingSource
            // 
            this.nmBindingSource.DataMember = "nm";
            this.nmBindingSource.DataSource = this.nmDataSet;
            // 
            // nmDataSet
            // 
            this.nmDataSet.DataSetName = "nmDataSet";
            this.nmDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // email_TextBox
            // 
            this.email_TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nmBindingSource, "Email:", true));
            this.email_TextBox.Location = new System.Drawing.Point(282, 238);
            this.email_TextBox.Multiline = true;
            this.email_TextBox.Name = "email_TextBox";
            this.email_TextBox.Size = new System.Drawing.Size(260, 43);
            this.email_TextBox.TabIndex = 4;
            this.email_TextBox.TextChanged += new System.EventHandler(this.email_TextBox_TextChanged);
            this.email_TextBox.Leave += new System.EventHandler(this.email_TextBox_Leave);
            // 
            // mobile_No_TextBox
            // 
            this.mobile_No_TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nmBindingSource, "Mobile No:", true));
            this.mobile_No_TextBox.Location = new System.Drawing.Point(282, 326);
            this.mobile_No_TextBox.Multiline = true;
            this.mobile_No_TextBox.Name = "mobile_No_TextBox";
            this.mobile_No_TextBox.Size = new System.Drawing.Size(260, 43);
            this.mobile_No_TextBox.TabIndex = 6;
            this.mobile_No_TextBox.TextChanged += new System.EventHandler(this.mobile_No_TextBox_TextChanged);
            this.mobile_No_TextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mobile_No_TextBox_KeyPress);
            // 
            // loan_Type_TextBox
            // 
            this.loan_Type_TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nmBindingSource, "Loan Type:", true));
            this.loan_Type_TextBox.Location = new System.Drawing.Point(282, 413);
            this.loan_Type_TextBox.Multiline = true;
            this.loan_Type_TextBox.Name = "loan_Type_TextBox";
            this.loan_Type_TextBox.Size = new System.Drawing.Size(260, 43);
            this.loan_Type_TextBox.TabIndex = 8;
            // 
            // amount_TextBox
            // 
            this.amount_TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nmBindingSource, "Amount:", true));
            this.amount_TextBox.Location = new System.Drawing.Point(282, 504);
            this.amount_TextBox.Multiline = true;
            this.amount_TextBox.Name = "amount_TextBox";
            this.amount_TextBox.Size = new System.Drawing.Size(260, 43);
            this.amount_TextBox.TabIndex = 10;
            this.amount_TextBox.TextChanged += new System.EventHandler(this.amount_TextBox_TextChanged);
            this.amount_TextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.amount_TextBox_KeyPress);
            // 
            // duration_TextBox
            // 
            this.duration_TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.nmBindingSource, "Duration:", true));
            this.duration_TextBox.Location = new System.Drawing.Point(282, 599);
            this.duration_TextBox.Multiline = true;
            this.duration_TextBox.Name = "duration_TextBox";
            this.duration_TextBox.Size = new System.Drawing.Size(260, 43);
            this.duration_TextBox.TabIndex = 12;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.MidnightBlue;
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(587, 89);
            this.panel3.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 25.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(78, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(277, 49);
            this.label1.TabIndex = 0;
            this.label1.Text = "New Members";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.nmDataGridView);
            this.panel2.Location = new System.Drawing.Point(701, 56);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1085, 767);
            this.panel2.TabIndex = 1;
            // 
            // nmDataGridView
            // 
            this.nmDataGridView.AutoGenerateColumns = false;
            this.nmDataGridView.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.nmDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.nmDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.nmDataGridView.DataSource = this.nmBindingSource;
            this.nmDataGridView.Location = new System.Drawing.Point(3, 19);
            this.nmDataGridView.Name = "nmDataGridView";
            this.nmDataGridView.RowHeadersWidth = 51;
            this.nmDataGridView.RowTemplate.Height = 24;
            this.nmDataGridView.Size = new System.Drawing.Size(979, 638);
            this.nmDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Name:";
            this.dataGridViewTextBoxColumn1.HeaderText = "Name:";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Email:";
            this.dataGridViewTextBoxColumn2.HeaderText = "Email:";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Mobile No:";
            this.dataGridViewTextBoxColumn3.HeaderText = "Mobile No:";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Loan Type:";
            this.dataGridViewTextBoxColumn4.HeaderText = "Loan Type:";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Amount:";
            this.dataGridViewTextBoxColumn5.HeaderText = "Amount:";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Duration:";
            this.dataGridViewTextBoxColumn6.HeaderText = "Duration:";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 125;
            // 
            // nmBindingNavigator
            // 
            this.nmBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.nmBindingNavigator.BindingSource = this.nmBindingSource;
            this.nmBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.nmBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.nmBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.nmBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.nmBindingNavigatorSaveItem});
            this.nmBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.nmBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.nmBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.nmBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.nmBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.nmBindingNavigator.Name = "nmBindingNavigator";
            this.nmBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.nmBindingNavigator.Size = new System.Drawing.Size(1351, 31);
            this.nmBindingNavigator.TabIndex = 2;
            this.nmBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(29, 28);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(45, 24);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // nmBindingNavigatorSaveItem
            // 
            this.nmBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.nmBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("nmBindingNavigatorSaveItem.Image")));
            this.nmBindingNavigatorSaveItem.Name = "nmBindingNavigatorSaveItem";
            this.nmBindingNavigatorSaveItem.Size = new System.Drawing.Size(29, 24);
            this.nmBindingNavigatorSaveItem.Text = "Save Data";
            this.nmBindingNavigatorSaveItem.Click += new System.EventHandler(this.nmBindingNavigatorSaveItem_Click);
            // 
            // nmTableAdapter
            // 
            this.nmTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.nmTableAdapter = this.nmTableAdapter;
            this.tableAdapterManager.UpdateOrder = login.nmDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // new_member
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1351, 879);
            this.Controls.Add(this.nmBindingNavigator);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "new_member";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "new_member";
            this.Load += new System.EventHandler(this.new_member_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmDataSet)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nmDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmBindingNavigator)).EndInit();
            this.nmBindingNavigator.ResumeLayout(false);
            this.nmBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private nmDataSet nmDataSet;
        private System.Windows.Forms.BindingSource nmBindingSource;
        private nmDataSetTableAdapters.nmTableAdapter nmTableAdapter;
        private nmDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator nmBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton nmBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox name_TextBox;
        private System.Windows.Forms.TextBox email_TextBox;
        private System.Windows.Forms.TextBox mobile_No_TextBox;
        private System.Windows.Forms.TextBox loan_Type_TextBox;
        private System.Windows.Forms.TextBox amount_TextBox;
        private System.Windows.Forms.TextBox duration_TextBox;
        private System.Windows.Forms.DataGridView nmDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}