﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login
{
    public partial class dashboard : Form
    {
        public dashboard()
        {
            InitializeComponent();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new loancalculator().Show();
            

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new new_member().Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new staff().Show();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            new LOANS().Show();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new About_us().Show();
        }

        private void exitApplicatiponToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void manageUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new loancalculator().Show();
        }

        private void lOGOUTToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            new contact_us().Show();
        }

        private void loanCalculatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void xitApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new LOANS().Show();
        }

        private void lOGOUTToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            new loancalculator().Show();
        }
    }
}
