﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace login
{
    public partial class staff : Form
    {
        public staff()
        {
            InitializeComponent();
        }

        private void tableBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tableBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.staffDataSet1);
            MessageBox.Show(" Save Successfully!!");

        }

        private void staff_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'staffDataSet1.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter.Fill(this.staffDataSet1.Table);

        }

        private void mobile_No_TextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void nameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) == false && Convert.ToInt32(e.KeyChar) != 8)
                if (e.KeyChar != ' ')
                {
                    MessageBox.Show("Enter Characters Only");
                    e.Handled = true;
                }
        }

        private void email_TextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void email_TextBox_Leave(object sender, EventArgs e)
        {
            string pattern = " ^([0-9a-zA-Z] ([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
            if (Regex.IsMatch(email_TextBox.Text, pattern))
            {
                errorProvider1.Clear();
            }
            else
            {
                errorProvider1.SetError(this.email_TextBox, "Please Enter Valid Email Address");
            }
        }
    }
}
